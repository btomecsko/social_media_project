package com.cookysys.social_media_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialMediaProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocialMediaProjectApplication.class, args);
	}

}
