package com.cookysys.social_media_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocialMediaProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
